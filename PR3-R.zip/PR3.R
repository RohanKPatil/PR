library(mvtnorm)

readCSV <- function()
{
  trainingdata <- read.csv("D:\\\\workspace\\training.csv")
  #dataArray = (trainingdata)[ ,1:ncol(trainingdata)-1]      #dataArray is the array of feature vectors 
  #classArray = (trainingdata)[ ,ncol(trainingdata)]         #classArray is the array of all classes
  return (trainingdata)
}


getArray <- function(x)
{
  trainingdata = readCSV()
  dataforlabel = trainingdata[which(trainingdata[,3]==x),]    #returns only the rows which have label=x
  datawithoutlabel = dataforlabel[,1:ncol(dataforlabel)-1]    #removes the last column i.e column of labels
  return (datawithoutlabel)
}

getMeanVector <- function(x)
{
  datawithoutlabel = getArray(x)
  meanvec <- numeric()      #creates an empty vector which can hold numeric i.e double type of data
  for(i in 1:ncol(datawithoutlabel))
  {
    meanvec[i] = mean(datawithoutlabel[,i])   #calculates mean for each feature and fills it in mean vector
  }
  return(meanvec)
}

getCovarianceMatrix <- function(x)
{
  datawithoutlabel = getArray(x)
  datamatrix = data.matrix(datawithoutlabel, rownames.force = NA)   #copies data in an empty matrix
  covmatrix = cov(datamatrix)
  return (covmatrix)
}

getProbDensity <- function(featurevector,testlabel)
{
  datawithoutlabel = getArray(testlabel)
  meanvector = getMeanVector(testlabel)   
  covariancematrix = getCovarianceMatrix(testlabel)
  probdensity = dmvnorm(featurevector,meanvector,covariancematrix,log=FALSE)  #calculates multivariate prob density
  return (probdensity)
  
}

getProbOfAllClasses <- function(featurevector)
{
  trainingdata = readCSV()
  labels = levels(trainingdata[,ncol(trainingdata)])   #labels contains all the distinct values in last col of trainingdata
  setofprob <- numeric()
  for(i in 1:length(labels))
  {
    setofprob[i] = getProbDensity(featurevector,labels[i])  #prob density of feature vector corresp. to each class is found
  }
  return(setofprob)
}

getClass <- function(featurevector)
{
  
  trainingdata = readCSV()
  labels = levels(trainingdata[,ncol(trainingdata)])
  setofprob = getProbOfAllClasses(featurevector)
  indexofmax = which.max(setofprob)   #finds the position in the vector of max probability
  predictedlabel = labels[indexofmax] #same position will have the corresp. label in labels vector
  return (predictedlabel)
  
}

getAllPredictedLabels <- function(setoffeaturevectors)
{
  setofpredictedlabels <- character()
  for(i in 1:nrow(setoffeaturevectors))
  {
    setofpredictedlabels[i] = getClass(setoffeaturevectors[i,])
  }
  return (setofpredictedlabels)
  
}

getNoOfMismatch <- function(percent)
{
  oldmydata = read.csv("D:\\workspace\\data.csv") #data.csv contains total data
  total = nrow(oldmydata)
  count = ceiling(percent / 100 * total)
  indexes = sample(1:total, count, replace=F)
  trainingdata <- oldmydata[-c(indexes[1:length(indexes)]),]  #removes specific rows from total data. Note the minus symbol
  testingdata <- oldmydata[c(indexes[1:length(indexes)]),]    
  
  write.csv(trainingdata,file="D:\\workspace\\training.csv",row.names = FALSE)
  write.csv(testingdata,file="D:\\workspace\\testing.csv",row.names = FALSE)
  
  setofactuallabels = character()
  setofpredictedlabels = character()
  for(i in 1:length(indexes))
  {
    setofactuallabels[i] = as.character((testingdata)[i,ncol(testingdata)])
  }
  
  testfeaturevectors <- testingdata[,1:(ncol(testingdata)-1)]
  setofpredictedlabels=getAllPredictedLabels(testfeaturevectors)
  
  v <- NULL
  df<- NULL
  for(i in 1:nrow(testfeaturevectors))
  {
    v = c(testfeaturevectors[i,1:ncol(testfeaturevectors)],setofactuallabels[i],setofpredictedlabels[i])
    df <- rbind(df,v)
  }
  
  write.table(df,file="D:\\workspace\\out.csv",sep = ",", col.names = F, row.names = F, append = F)
  #out.csv contains the output which is in the format -> (feature vector, actual label, predicted label)
  
  mismatch = 0
  
  for(i in 1:length(setofactuallabels))
  {
    if(setofactuallabels[i]!=setofpredictedlabels[i])
    {
      mismatch = mismatch+1
    }
  }
  
  #return(mismatch)
  #mismatch is only calculated but not used further, can be used for calculating error percentage
  return(df)
}

getConfusionMatrix <- function(percent)
{
  oldmydata = read.csv("D:\\workspace\\data.csv") #data.csv contains total data
  labels = levels(oldmydata[,ncol(oldmydata)])  #gives all the labels in original data
  
  confusionmatrix = matrix(numeric(length(labels)*length(labels)),
                           nrow = length(labels),
                           ncol = length(labels),
                           byrow = T)
  
  #creates an empty confusion matrix of size n*n where n=no of labels
  
  for(i in 1:10)
  {
    
    getNoOfMismatch(percent)
    
    iterationresult = read.csv("D:\\workspace\\out.csv",header = F)
    
    vec = numeric(length(labels)*length(labels))
    
    for(j in 1:nrow(iterationresult))
    {
      actuallabel = iterationresult[j,3]
      actuallabelindex = which(labels==actuallabel)
      
      predictedlabel = iterationresult[j,4]
      predictedlabelindex = which(labels==predictedlabel)
      
      vec[(actuallabelindex-1)*length(labels)+predictedlabelindex] = vec[(actuallabelindex-1)*length(labels)+predictedlabelindex] +1
      
    }
    print("Matrix vector")
    print(vec)
    confusionmatrix = confusionmatrix + matrix(vec,
                                               nrow = length(labels),
                                               ncol = length(labels),
                                               byrow = TRUE)
    #confusion matrix of each iteration gets added in the previous one as we want summation of all the matrices
    
    #print(confusionmatrix)
  }
  print("Aggregate Confusion Matrix (without taking average)")
  print(confusionmatrix)
}


#readCSV()
#getMeanVector("A")
#getCovarianceMatrix("A")
#getProbDensity(c(2.1,3.5),"B")
#getProbOfAllClasses(c(2.1,3.5))
#getClass(c(2.9,3.1))
#getAllPredictedLabels(data.frame(c(2.9,3.1),c(1.2,3.8),c(3.4,1.9)))
getConfusionMatrix(30)    #30% of total data will be used for testing, remaining for training